#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
using namespace std;

class MyString
{
private:
	shared_ptr<char> str;
	size_t size;
protected:
public:

	MyString():str(nullptr),size(0)
	{}


	MyString(const MyString& rhs) = delete;
	MyString& operator = (const MyString& rhs) = delete;

	

	const char* const Get_String() const 
	{
		return str.get();
	}


	void Append(const char* param_string)
	{
		int param_str_size = strlen(param_string);
		int str_size = size;

		if (str == nullptr) {
			str.reset(new char[param_str_size+1], default_delete<char[]>());
			memset(str.get(), 0, param_str_size + 1);
			for (int i = 0; i < param_str_size + 1; i++)
				str.get()[i] = param_string[i];

			size = param_str_size;

			return;
		}

		shared_ptr<char>backup_string(new char[str_size + 1], default_delete<char[]>());
		memset(backup_string.get(), 0, str_size+1);

		for (int i = 0; i < str_size + 1; i++)
		{
			backup_string.get()[i] = str.get()[i];
		}

		str_size += param_str_size;

		shared_ptr<char>copy_string(new char[str_size + 1], default_delete<char[]>());
		memset(copy_string.get(), 0, str_size +1);


		for (int i = 0; i < size; i++) 
			copy_string.get()[i] = backup_string.get()[i];

		
		for (int i = size; i < str_size; i++)
			copy_string.get()[i] = param_string[i-size];
		

		str.reset(new char[str_size + 1], default_delete<char[]>());
		memset(str.get(), 0, str_size+1);

		str.swap(copy_string);
		size = str_size;
		
	}

};

int main() 
{
	const char a[] = "hello";
	const char b[] = "world";
	MyString str;
	str.Append(a);

	cout << str.Get_String() << endl;
	str.Append(b);
	cout << str.Get_String() << endl;
	



	cout << endl << endl;
	


}