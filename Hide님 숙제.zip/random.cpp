#include"NODE.hpp"
#include"ITERATOR.hpp"
#include"UI_MANAGER.hpp"


int _tmain()
{

	ITERATOR iterator;
	UI_MANAGER ui(iterator);
	ui.Start();
	

}
